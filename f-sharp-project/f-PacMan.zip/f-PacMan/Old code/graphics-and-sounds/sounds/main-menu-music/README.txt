https://www.youtube.com/watch?v=qtZ0hl-unM4

Above is a link to the original youtube video for the sound.

Creator stated there will be no copy right issues creators stated the following "To anyone wondering.. You can use this song ANYWHERE you want. And you don't need to give credit if it's not appropriate/fits your creation. (but of course id like if you do :P) And if you use it in any games you create, I'd really love to play your game! We're all creating content for each other. And I belive strongly that you will give me credit where it its needed, and same to you. So please guys, don't worry about using the song anywhere. Use it as much as you want. I made this for you :)"

See image in folder named Creator-Rights